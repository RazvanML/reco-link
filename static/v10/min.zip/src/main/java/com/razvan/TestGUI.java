package com.razvan;

import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "")
@PageTitle("My Test page")
public class TestGUI extends VerticalLayout {
	
	public TestGUI() {
		add(new Text("Hello Vaadin 10!"));
	}

}
