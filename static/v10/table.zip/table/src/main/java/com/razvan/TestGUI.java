package com.razvan;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

enum colorType{Red,Green,Blue,Yellow,White,Black};

class RandomRecordGenerator {
	private final static List<String> first= Arrays.asList("John","Alice","Mary","Tom","Helen","Bob","Tiffany");
	private final static List<String> last= Arrays.asList("Smith","Johnson","Ingram","Lincoln","Smithson","Brandon","Richardson");
	private Random rand = new Random();

	private String getRandom(List<String> list) {
		return list.get(rand.nextInt(list.size()));
	}
	
	public Record getRandomRecord() {
		Record r = new Record();
		char letter = (char) ((int)'A' + rand.nextInt(26));
		r.setName(getRandom(first) + " " + letter  + ". " + getRandom(last));		
		r.setAge(rand.nextInt(100) + 1);
		r.setCheck(rand.nextBoolean());
		r.setValue(rand.nextDouble()*100);
		if (rand.nextInt(10) > 3) // otherwise, value2 will remain null
			r.setValue2(rand.nextDouble()*100);
		r.setColor(colorType.values()[rand.nextInt(colorType.values().length)]);		
		return r;
	}

}

class Record {
	private String name;
	private Integer age;
	private Double value;
	private Double value2;
	private Boolean check;
	private colorType color;
	
	public Record() {
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	public Double getValue2() {
		return value2;
	}
	public void setValue2(Double value2) {
		this.value2 = value2;
	}
	public Boolean getCheck() {
		return check;
	}
	public void setCheck(Boolean check) {
		this.check = check;
	}
	public colorType getColor() {
		return color;
	}
	public void setColor(colorType color) {
		this.color = color;
	}
}



@Route(value = "")
@PageTitle("My Test page")
public class TestGUI extends VerticalLayout {

	private static Logger log =  LoggerFactory.getLogger(TestGUI.class);
	
	static List<Record> rec = new ArrayList<>();
	static {
		RandomRecordGenerator rrg = new RandomRecordGenerator();
		log.info("Starting generate data");
		for (int i = 0 ; i != 10000;i++)
			rec.add(rrg.getRandomRecord());
		log.info("Done generate data");
	}
	
	public TestGUI() {
		
		Grid<Record> grid = new Grid<>();
		grid.setItems(rec);
		grid.addColumn(name->name.getName()).setHeader("Name").setSortable(true);
		grid.addColumn(name->name.getAge()).setHeader("Age").setSortable(true);
		grid.addColumn(name->name.getValue()).setHeader("Value").setSortable(true);
		grid.addColumn(name->name.getValue2()).setHeader("Value2").setSortable(true);
		grid.addColumn(name->name.getCheck()).setHeader("Check").setSortable(true);
		grid.addColumn(name->name.getColor()).setHeader("Color").setSortable(true);
		grid.setSizeFull();
		grid.addSelectionListener(x->{
			if (x.getAllSelectedItems().size() > 0)
				log.info("Selection changed to: "+x.getFirstSelectedItem().get().getName());
			else
				log.info("No element selected");
			});
		add(grid);
		setSizeFull();
	}

}
