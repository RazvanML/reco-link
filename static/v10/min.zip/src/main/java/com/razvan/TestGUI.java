package com.razvan;

import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@Route(value = "")
@PageTitle("My Test page")
public class TestGUI extends VerticalLayout {
	
	public TestGUI() {
		add(new Label("Hello Vaadin 10"));
	}

}
